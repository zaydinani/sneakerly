<?php
/**
 * Index file
 *
 * @package Astra
 * @since 1.4.8
 */

/* Silence is golden, and we agree. */
