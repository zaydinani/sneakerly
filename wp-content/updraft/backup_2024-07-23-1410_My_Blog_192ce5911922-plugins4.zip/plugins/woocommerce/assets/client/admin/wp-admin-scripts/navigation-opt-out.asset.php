<?php return array('dependencies' => array('wp-components', 'wp-element', 'wp-i18n'), 'version' => 'c4c64ed98a6890ec69be');
