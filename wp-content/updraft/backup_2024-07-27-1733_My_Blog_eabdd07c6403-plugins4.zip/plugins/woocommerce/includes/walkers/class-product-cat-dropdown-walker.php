<?php
/**
 * Legacy WC_Product_Cat_Dropdown_Walker file
 *
 * @package WooCommerce\Classes\Walkers
 * @deprecated 3.4.0
 */

defined( 'ABSPATH' ) || exit;

require dirname( __FILE__ ) . '/class-wc-product-cat-dropdown-walker.php';
