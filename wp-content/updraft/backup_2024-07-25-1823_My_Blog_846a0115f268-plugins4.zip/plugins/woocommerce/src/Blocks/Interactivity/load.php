<?php
require __DIR__ . '/class-wc-interactivity-initial-state.php';
require __DIR__ . '/initial-state.php';
require __DIR__ . '/scripts.php';
