<!-- start Simple Custom CSS and JS -->
<script type="text/javascript">
document.addEventListener('DOMContentLoaded', function() {
    var wishlistCompareElement = document.querySelector('.wl-wishlist-compare-txt');
    if (wishlistCompareElement) {
        wishlistCompareElement.remove();
    }
});
</script>
<!-- end Simple Custom CSS and JS -->
